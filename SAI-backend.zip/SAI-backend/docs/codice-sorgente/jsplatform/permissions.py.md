# permissions.py

<COMPLETATO>


### class IsTeacherOrReadOnly(BasePermission)

Rappresenta la [permission](https://www.django-rest-framework.org/api-guide/permissions/)  "se l'utente non è un insegnate, controlla se è autorizzato ad invocare il metodo che ha richiesto".

***def has_permission(self, request, view)***

* Se l'utente è un insegnante allora è autorizzato, quindi restituisce *True*.

* Se l'utente non è un insegnate e vuole usare un metodo per cui è necessario essere insegnante allora non è autorizzato, quindi restituisce *False*.

* Se l'utente non è un insegnate e vuole usare un metodo per cui non è necessario essere insegnante allora è autorizzato e restituisce *True*.

### class TeachersOnly(BasePermission)

Rappresenta la [permission](https://www.django-rest-framework.org/api-guide/permissions/)  "l'utente deve essere un insegnante".

***def has_permission(self, request, view)***

Restituisce *True* se l'utente è un insegnante, altrimenti *False*.

