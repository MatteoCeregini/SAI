# apps.py

Per maggiori informazioni, consulta la [documentazione Django](https://docs.djangoproject.com/en/3.2/ref/applications/).

