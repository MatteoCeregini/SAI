# consumers.py

### class ExamListConsumer(AsyncWebsocketConsumer)

Rappresenta un [consumer](https://channels.readthedocs.io/en/latest/topics/consumers.html) usato per inviare
 aggiornamenti quando un esame viene bloccato (lock) o sbloccato (unlock).
 
***async def connect(self)***

Se l'utente che si connette non è anonimo, esso viene registrato al gruppo dell'*exam_list* così che possa ricevere aggiornamenti.

***async def disconnect(self, close_code)***

L'utente viene disconesso, così che non riceva più aggiornamenti relativi all'*exam_list*.

***async def receive(self, text_data)***

<Metodo che viene chiamato direttamente dal backend django....., scrivere su models metodo save>

* Se l'azione specificata è "lock" allora l'esame viene bloccato e comunicato ai membri del gruppo *exam_list*.

* Se l'azione specificata "unlock" allora l'esame viene sbloccato e comunicato ai membri del gruppo *exam_list*.

***async def broadcast_lock(self, exam_id, locked_by)***

Comunica ai membri del gruppo *exam_list* che l'utente (specificato dal parametro *locked_by*) ha fatto lock dell'esame identificato da *exam_id*.

***async def broadcast_unlock(self, exam_id)***

Comunica ai membri del gruppo *exam_list* che l'esame identificato da *exam_id* è stato sbloccato (unlocked). 

***async def exam_lock(self, event)***

Se un esame non è visibile dall'utente allora non gli viene comunicato l'evento di lock relativo a quell'esame. Se invece l'esame è visibile dall'utente,
 gli viene comunicato l'evento di lock.

***async def exam_unlock(self, event)***

Se un esame non è visibile dall'utente allora non gli viene comunicato l'evento di unlock relativo a quell'esame. Se invece l'esame è visibile dall'utente,
 gli viene comunicato l'evento di unlock.

***def in_user_scope(self, exam_id)***

Restituisce True se l'esame identificato da *exam_id* è visibile dall'utente, False altrimenti.


### class ExamLockConsumer(AsyncWebsocketConsumer)

Rappresenta un [consumer](https://channels.readthedocs.io/en/latest/topics/consumers.html) usato per garantire la mutua esclusione durante 
la modifica degli esami.

***async def connect(self)***

Se l'utente che si connette non è anonimo e non c'è già un altro utente che sta modificando l'esame, l'utente viene registrato al gruppo relativo all'esame e l'esame viene
bloccato.

***async def disconnect(self, close_code)***

L'utente viene disconesso, gestendo anche il caso in cui l'utente abbia più tab aperte.

***async def kill_connection(self, event)***

Viene utilizzato dal metodo *disconnect* per gestire il caso in cui l'utente abbia più tab aperte.

***def who_locked(self, exam_id)***

Restituisce l'utente che ha fatto lock dell'esame identificato da *exam_id*.

***def lock_exam(self, exam_id)***

Fa il lock dell'esame identificato da *exam_id*.

***def unlock_exam(self, exam_id)***

Fa l'unlock dell'esame identificato da *exam_id*.
