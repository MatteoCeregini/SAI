# views.py

### class QuestionViewSet(viewsets.ModelViewSet)

Rappresenta un insieme di view per creare, modificare domande a risposta multipla. Solo gli insegnanti possono creare o modificare le domande.
Gli studenti possono solo visualizzare la domande a loro assegnate.

***def get_queryset(self)***

Restringe il queryset così che lo studente possa visualizzare solo la domanda corrente.

### class ExamViewSet(viewsets.ModelViewSet)

Rappresenta un insieme di view per creare, modificare e accedere agli esami. Solo gli insegnanti possono creare o modificare gli esami.
Gli studenti possono visualizzare solo gli esami correnti, ossia quelli che sono già iniziati e non ancora finiti.

***def update(self, request, pk=None)***

L'esame viene aggiornato come specificato dal parametro *request*. Sono quindi aggiornate di conseguenza
tutte le domande ed esercizi relativi all'esame.

***def mock(self, request, \*\*kwargs)***

Restituisce un esempio di esame contenente una possibile lista di domande, scelte secondo le impostazioni dell'esame.

***def my_exam(self, request, \*\*kwargs)***

Se l'utente è uno studente  e non gli è stato assegnato un esercizio (domanda o esercizio Javascript) e l'esame è già iniziato, gliene viene assegnato uno.
Altrimenti, se allo studente è già stato assegnato una domanda o esercizio, viene restituita la domanda o esercizio corrente.

***def terminate(self, request, \*\*kwargs)***

Termina l'esame attualmente in corso.

***def report(self, request, \*\*kwargs)***

Restituisce il report dell'esame se già generato, altrimento lo genera e poi viene restituito.

***def perform_create(self, serializer)***

???

***def get_renderer_context(self)***

???



### class ExerciseViewSet(viewsets.ModelViewSet)

Rappresenta un insieme di view per creare, modificare esercizi Javascript. Solo gli insegnanti possono creare o modificare gli esercizi.
Gli studenti possono solo visualizzare gli esercizi a loro assegnati.

***def get_queryset(self)***

Restringe il queryset così che lo studente possa visualizzare solo l'esercizio corrente.

### class GivenAnswerViewSet(viewsets.ModelViewSet)

???

*** def get_queryset(self)***

???

***def create(self, request, \*\*kwargs)***

???

***def perform_create(self, serializer)***

???

***def multiple(self, request, pk=None, \*\*kwargs)***

???

### class SubmissionViewSet(viewsets.ModelViewSet)

Rappresenta un insieme di view per creare, recuperare e elencare le submission relative ad un esercizio e
consegnare le submission che sono ammissibili. Gli insegnanti possono accedere alle submission di tutti gli studenti
relative ad un esercizio, mentre gli studenti posssono accedere soltanto alle proprie.

***def get_queryset(self)***

Restringe il queryset così che lo studente possa accedere soltanto alle proprie submission relative ad un esercizio.

***def perform_create(self, serializer)***

???

***def turn_in(self, request, pk=None, \*\*kwargs)***

Invoca il metodo *turn_in()* di una specifica submission.
