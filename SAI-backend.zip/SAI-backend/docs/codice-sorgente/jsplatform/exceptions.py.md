# exceptions.py

### class SubmissionAlreadyTurnedIn(Exception)

???

### class NotEligibleForTurningIn(Exception)

???

### class InvalidAnswerException(Exception)

???

### class ExamNotOverYet(Exception)

???

### class OutOfCategories(Exception)

???

### class InvalidCategoryType(Exception)

???
