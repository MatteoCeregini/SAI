# admin.py

In questo file vengono specificati quali modelli (vedi models.py) devono essere editabili nella admin interface. 
Per maggiori informazioni, consulta la [documentazione Django](https://docs.djangoproject.com/en/3.2/ref/contrib/admin/).
