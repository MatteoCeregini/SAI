# utils.py

<COMPLETATO>

***def run_code_in_vm(code, testcases_json)***

Dato un programma Javascript (codice sorgente) rappresentato dalla stringa *code* e una lista di testcase, esegue il programma per ogni testcase all'interno di una macchina virtuale Javascript e 
restituisce i risultati ottenuti in formato json.
