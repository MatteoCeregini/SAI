# runUserProgram.js

<chiedi chiarimenti su codice riga 90-101>

***Utilizzo:***
*node runUserProgram.js programCode testCases*, dove:

* *programCode* è una stringa contenente la definizione di una funzione, che deve essere
eseguita utilizzando gli input contenuti in *testCases*.

* *testCases* è un array di oggetti dove ogni oggetto è costituito dai seguenti attributi:
	* *id*: è un numero che identifica univocamente il testcase ed è usato da Django per mantenere le corrette relazioni tra i modelli di dati.
	
	* *input* è una stringa contenente gli argomenti con cui la funzione deve essere valutata. Gli argomenti sono separati da un carattere speciale 
	usato come separatore.


***Output: ***

Il programma stampa sulla console un array (che viene letto da Django tramite subprocess.check_output()). Ogni elemento dell'array 
è un oggetto che corrisponde a un casetest ed è costituito dai seguenti attributi:

* *id*: è un numero che identifica univocamente il testcase.
* *output*: è il valore restituito dalla funzione che è stata eseguita con l'input del testcase. Se il valore restituito è undefined, in output contiene la stringa "undefined".

Se la funzione Javascript fallisce nell'eseguire un test case, all'interno dell'oggetto relativo al testcase ci sarà un attributo *error* contenente le informazioni relative all'errore che
ha causato il fallimento del programma.


### Funzioni utilizzate:

***function listToCSVString(list) ***

Dato una array di stringhe, restituisce una stringa di valori separati da virgole racchiusi tra parentesi. 
Questa funzione viene usata per convertire un array di parametri in una stringa che può essere aggiunta dopo al nome di una funzione 
così che si possa invocare la funzione.

***function functionToRunnable(func, params)***

Data una stringa che rappresenta una funzione e una stringa che rappresenta i suoi parametri, restituisce una stringa contenente la definizione della funzione
seguita dal nome della funzione e dai suoi parametri.

***function stringifyError(err, filter, space)***

Restituisce una stringa JSON contenente le informazioni relative all'errore *err*.


