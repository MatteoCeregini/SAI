# runWithAssertions.js

***Utilizzo:***
*node runWithAssertions.js programCode assertions*, dove:

* *programCode* è una stringa che rappresenta un programma Javascript.
* *assertions* è un'array di stringhe che rappresentano le asserzioni<create usando *node assertions*>.

***Output:***

Il programma stampa sulla console un array (che viene letto da Django tramite subprocess.check_output()). 
Ogni elemento dell'array è un oggetto che corrisponde ad una asserzione, rappresentata come un oggetto costituito dai seguenti
attributi:

* *id* è un numero che rappresenta l'id dell'asserzione nel database di Django.
* *assertion* è una stringa che rappresenta l'asserzione.
* *public* è un valore booleano che indica se l'asserzione può essere visualizzata dall'utente oppure è segreta.
* *passed* è un valore booleano che indica se il programma ha superato l'asserzione.
* *error* è una stringa che rappresenta l'errore generato dal fallimento dell'asserzione. Questo attributo è presente solo se l'asserzione è fallita.

### Funzioni utilizzate


***function prettyPrintError(e)***

Restituisce una stringa che contiene le informazioni riguardanti un errore avvenuto durante l'esecuzione del programma oppure un errore di timeout se il programma
ha impiegato troppo tempo per terminare.



***function prettyPrintAssertionError(e)***

Restituisce una stringa che contiene le informazioni riguardante un errore generato dal fallimento di una asserzione.

