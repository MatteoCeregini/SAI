# serializers.py

### class ExamSerializer(serializers.ModelSerializer)

Rappresenta un [serializer](https://www.django-rest-framework.org/api-guide/serializers/#modelserializer)
 usato per la creazione, la modifica di un esame e per l'accesso alle informazioni relative all'esame.

***def \_\_init\_\_(self, \*args, \*\*kwargs)***

<>
* Se l'utente che ha fatto request è un insegnante, mostra tutti gli esercizi e domande dell'esame.

* Se l'utente che ha fattor request è uno studente, mostra l'esercizio o domanda corrente.

***def create(self, validated_data)***

Crea l'esame usando le informazioni contenute in *validated_data*.

***def update(self, instance, validated_data)***

Aggiorna l'esame usando le informazioni contenute in *validated_data*.

***def get_exercise(self, obj)***

***def get_question(self, obj)***

***def get_submissions(self, obj)***

***def get_locked_by(self, obj)***

### class CategorySerializer(serializers.ModelSerializer)

***def \_\_init\_\_(self, \*args, \*\*kwargs)***

### class TestCaseSerializer(serializers.ModelSerializer)

***def \_\_init\_\_(self, \*args, \*\*kwargs)***

***def create(self, validated_data)***

### class QuestionSerializer(serializers.ModelSerializer)

***def \_\_init\_\_(self, \*args, \*\*kwargs)***

***def create(self, validated_data)***

***def update(self, instance, validated_data)***

### class AnswerSerializer(serializers.ModelSerializer)

***def \_\_init\_\_(self, \*args, \*\*kwargs)***

### class ExerciseSerializer(serializers.ModelSerializer)

***def \_\_init\_\_(self, \*args, \*\*kwargs)***

***def create(self, validated_data)***

***def update(self, instance, validated_data)***

### class GivenAnswerSerializer(serializers.ModelSerializer)

### class SubmissionSerializer(serializers.ModelSerializer)

***def \_\_init\_\_(self, \*args, \*\*kwargs)***

***def create(self, validated_data)***


