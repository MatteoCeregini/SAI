# throttles.py

<COMPLETATO>

### class UserSubmissionThrottle(UserRateThrottle)
Rappresenta una policy di [throttling](https://www.django-rest-framework.org/api-guide/throttling/) che determina se una request da parte dell'utente
 deve essere approvata oppure no.
 
***def parse_rate(self, rate)***

Restituisce la tupla *(1, 30)*. Cioè l'utente può fare al massimo una request ogni trenta secondi.
