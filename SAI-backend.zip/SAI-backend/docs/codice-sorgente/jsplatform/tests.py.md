# tests.py

### class ExerciseViewSetTestCase(TestCase)

Rappresenta un insieme di test relativi alla classe *ExerciseViewSet*.

***def setUp(self)***

Vengono create gli oggetti e variabili necessari per poter eseguire i testcase.

***def get_post_request(self)***

Restituisce un esempio di POST request per la creazione di un esercizio.

***def test_create_exercise(self)***

Testa che solo gli insegnanti possono creare gli esercizi.

***def test_update_exercise(self)***

Testa che la modifica di un esercizio fatta da un insegnante viene effettuata correttamente.

***def test_testcase_retrieve_permissions(self)***

Testa che gli studenti possono accedere solo ai testcase pubblici, mentre gli insegnanti possono accedere sia a quelli pubblici
che a quelli segreti.

### class SubmissionViewSetTestCase(TestCase)

Rappresenta un insieme di test relativi alla classe *SubmissionViewSet*.


***def setUp(self)***

Vengono create gli oggetti e variabili necessari per poter eseguire i testcase.

***def get_post_request(self, code, pk)***

Restituisce un esempio di POST request per la creazione di una submission con codice *code*.

***def get_get_request(self, exercise_pk, submission_pk)***

Restituisce un esempio di GET request per accedere ad una submission.

***def test_submission_processing(self)***

Testa che le informazioni ottenute dopo l'esecuzione del codice di una submission siano corrette.


***def test_submission_detail_permissions(self)***

Testa che gli studenti possono solo accedere ai dettagli dei testcase pubblici relativi alle loro submission, mentre gli insegnanti
possono accedere anche ai dettagli dei testacase segreti.

***def test_submission_owner_permissions(self)***

Testa che gli studenti possono accedere solo alle loro submission, mentre gli insegnanti possono accedere a qualsiasi submission.

