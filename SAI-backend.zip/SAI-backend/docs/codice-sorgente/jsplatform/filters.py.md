# filters.py

### class TeacherOrOwnedOnly(filters.BaseFilterBackend)

???

### class TeacherOrAssignedOnly(filters.BaseFilterBackend)

???

### class ExamCreatorAndAllowed(filters.BaseFilterBackend)

Rappresenta la policy di [filtering](https://www.django-rest-framework.org/api-guide/filtering/) "il queryset di un esame è ristretto agli utenti
che hanno creato l'esame o sono stati autorizzati ad accedere all'esame."

***def filter_queryset(self, request, queryset, view)***

Restringe il queryset così che l'utente che ha fatto request possa accedere solo agli esami da lui creati e a quelli per cui è autorizzato ad accedere.

