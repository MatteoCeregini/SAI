# renderers.py

Per maggiori informazioni, consulta la documentazione [Django-REST-framework](https://www.django-rest-framework.org/api-guide/renderers/).
