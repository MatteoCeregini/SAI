# socket_auth_middleware.py

***def get_user(token_key)***

Restituisce l'utente associato alla *token_key*.


### Class TokenAuthMiddleware(BaseMiddleware)
Rappresenta un authentication middleware. Per maggiori informazioni, consulta la [documentazione Django channels](https://channels.readthedocs.io/en/stable/topics/authentication.html).

***async def __call__(self, scope, receive, send)***

L'utente è autenticato usando un token e viene aggiunto allo scope.
