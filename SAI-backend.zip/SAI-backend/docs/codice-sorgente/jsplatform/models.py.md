# models.py

<COMPLETATO>

### class Exam(models.Model)

Rappresenta un esame. Ciascun esame è caratterizzato da un nome, da una data d'inizio e da una data di fine.

***def get_number_of_items_per_exam(self)***

Restituisce il numero di domande e esercizi Javascript che compongono l'esame.

***get_current_progress(self)***

Restituisce un dizionario che contiene:

* Il numero corrente di partecipanti all'esame.
* La lista contenente per ogni partecipante, le sue informazioni identificative e il suo progresso espresso
come numero di esercizi e domande completati.
* Il numero di esercizi e domande che compongono l'esame.
* Il progresso medio dell'esame.
* Il numero di partecipanti che hanno completato l'esame.

***get_mock_exam(self, user)***

Restituisce un esempio di esame in modalità read-only.

***get_item_for(self, user, force_next=False)***

* Se invocato per la prima volta restituisce una domanda o esercizio Javascript casuale preso dall'esame dello studente *user*.
* Se *force_next=False* restituisce la domanda o esercizio Javascript corrente dell'esame dello studente *user*.
* Se *force_next=True* restituisce una domanda o un esercizio Javascript causale che lo studente *user* non ha ancora completato.
* Se lo studente *user* ha completato tutte le domande o esercizi javascript di una categoria, restituisce (se esiste) una domanda o
 esercizio javascript appartente ad un altra categoria, altrimenti restituisce *None*.

### class Category(models.Model)

Rappresenta una categoria di esercizi Javascript o di domande. Ciascuna categoria è identificata da un nome. Una categoria può 
rappresentare un insieme di domande aggregate, cioè domande che condividono un testo introduttivo e sono visualizzate una dopo l'altra.


### class ExamReport(models.Model)

Rappresenta un report relativo ad un esame. Un report viene genarato dopo la fine dell'esame e contiene le risposte date dagli studenti
che hanno partecipato all'esame.

***def generate_zip_archive(self)***

Crea in memoria il file zip contenente i report dell'esame di ogni partecipante.

***generate_headers(self)***

Genera gli headers del report, specificando quali informazioni sono contenute nel report.<br>
Ogni studente che ha partecipato all'esame è identificato da:

* Email dello studente.
* Corso dello studente.


Per ogni esercizio Javascript <dell'esame dello studente,> ci interessano le seguenti informazioni:

* Testo dell'esercizio.
* Sottomissione dello studente (codice sorgente del programma scritto dallo studente).
* Orario di visualizzazione dell'esercizio.
* Orario di consegna dell'esercizio.
* Testcase superati.
* Testcase falliti.

Per ogni domanda <dell'esame dello studente,> ci interessano le seguenti informazioni:

* Testo della domanda.
* Risposta data dallo studente.
* Se la risposta data dallo studente è corretta.
* Orario di visualizzazione della domanda.
* Orario della risposta (quando lo studente ha risposto alla domanda). 

***populate(self)***

Popola il report con le informazioni relative all'esame.


### class Question(models.Model)

Rappresenta una domanda dell'esame, che può essere a riposta aperta oppure a risposta multipla.
 Una domanda fa parte di una categoria di domande.

### class Exercise(models.Model)

Rappresenta un esercizio Javascript, in cui lo studente deve consegnare in forma testuale il codice sorgente di un programma.
 Un esercizio fa parte di una categoria di esercizi.

***public_testcases(self)***

Restituisce tutti i testcase *pubblici* relativi all'esercizio Javascript.

### class ExamProgress(models.Model)

Rappresenta il progesso di uno studente per un esame, ossia gli esericizi sono stati stati completati e l'esercizio
che lo studente sta facendo.


***def get_progress_percentage(self)***

Restituisce un float con due cifre decimali che rappresenta la percentuale di completamento dell'esame in termini di elementi completati
 rispetto al numero di esercizi o domande dell'esame.
 
***def get_progress_as_dict(self)***

Restituisce un dizionario che contiene le informazioni all'esame di uno specifico studente, tra cui gli esercizi e domande visualizzati dall'utente, 
le risposte date e le soluzioni inviate.

***def generate_pdf(self)***

Genera un file pdf (salvato come "nome cognome studente.pdf") contenente gli esercizi e domande visualizzate dallo studente, le risposte date alle domande e le soluzioni inviate degli esercizi.   

***move_to_next_type(self)***

Aggiorna la tipologia di oggetti (esercizi Javascript o domande) che devono essere date allo studente:

* Se allo studente sono stati dati tutti gli esercizi Javascript e tutte le domande, allora non c'è nessun altro oggetto da dare.

* Se allo studente sono stati dati per primi tutti gli esercizi Javascript, verrano quindi date le domande.

* Se allo studente sono state date per prime tutte le domande, verrano quindi dati gli esercizi Javascript.

***move_to_next_category(self)***

La categoria di domande o esercizi Javascript attuale viene considerata come completata (esaurita), 
quindi viene scelta in maniera casuale una nuova categoria quelle rimanenti.

***simulate(self)***

Restituisce un esempio di esame, rappresentato da una lista di domande e  da una lista di esercizi Javascript. 

***get_next_item(self, force_next=False)***

* Se *force_next=False* restituisce l'oggetto corrente della categoria corrente.

* Se *force_next=True* restituisce un oggetto casuale preso dalla categoria corrente. Se non ci sono più oggetti disponibili, 
la categoria corrente viene rimpiazzata con la categoria successiva e un suo oggetto viene scelto casualemente e restituito.

* Se l'esame è stato completato, ossia tutte le domande ed esercizi Javascript sono stati dati allo studente, restutisce *None*.

***_get_item(self, type)***

Aggiorna l'oggetto corrente (domanda o esercizio Javascript, come specificato dal parametro *type*) come completato. Quindi, 
restituisce un oggetto scelto casualmente tra quelli non completati. Se tutti gli oggetti della categoria corrente sono completati
restituisce *None*.


### class ExamCompletedQuestionsThroughModel(models.Model)

???

### class ExamCompletedExercisesThroughModel(models.Model)

???

### class TestCase(models.Model)

Rappresenta un testcase per un esercizio Javascript. 


### class Submission(models.Model)
Rappresenta un programma Javascript scritto da uno studente ed è relativo a uno specifico esercizio.
 Il programma viene testato usando i testcase dell'esercizio. Il numero di testcases passati determina se 
 il programma è considerato ammissibile.

***get_passed_testcases(self)***

Restituisce il numero di testcases che il programma ha superato.

***public_details(self)***

Restituisce un dizionario contente le informazioni pubbliche relative al programma Javascript:

* Quali testcase pubblici che non sono stati superati.
* Quali testcase "segreti" non sono stati superati. 
* Se durante l'esecuzione del programma avviene un errore, il dizionario contiene soltanto informazioni
relative all'errore.

***eval_submission(self)***

Il programma Javascript viene testato usando i testcases e se ne ha superati abbastanza allora è considerato ammissibile, altrimenti no.

***turn_in(self)***

L'esercizio Javascript corrente viene considerato completato, quindi un altro esercizio casuale viene scelto come esercizio successivo.

### class Answer(models.Model)

Rappresenta una risposta ad una domanda a risposta multipla.

### class GivenAnswer(models.Model)

Rappresenta la risposta data dallo studente ad una domanda durante un esame.







