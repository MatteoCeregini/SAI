# urls.py

Per generare automaticamente lo schema, vedi [django-rest-framework](https://www.django-rest-framework.org/api-guide/schemas/).
