# pdf.py

***def preprocess_html_for_pdf(html)***

<Fa il preprocessing dell'html elimando i tag "`" e rimpiazzandoli con "pre"s>

***def render_to_pdf(template_src, context_dict)***

Questa funzione restituisce un pdf creato a partire da un template HTML e da un [dizionario](https://docs.djangoproject.com/en/3.2/ref/templates/api/#rendering-a-context) contenente le informazioni che
sono devono essere inserite dinamicamente nel HTML.
