# views.py

### class TeacherList(generics.ListAPIView)

Rappresenta una [API view](https://www.django-rest-framework.org/api-guide/generic-views/#listcreateapiview) per ottenere la lista di tutti gli insegnanti.
