# models.py

### class User(AbstractUser)

Rappresenta un utente. Ciascun utente caratterizzato da:

* Il nome dell'utente.
* Il cognome dell'utente.
* L'email di ateneo.
* Se è uno studente oppure un insegnante.
* Il corso a quale appartiene (A, B, oppure C).

***def save(self, \*args, \*\*kwargs)***

Crea l'oggetto che rappresenta l'utente. Se l'email dell'utente termina con *@unipi.it* allora l'utente è un insegnante.

***def get_full_name(self)***

Restituisce una stringa contenente il nome e cognome dell'utente in caratteri maiuscoli.
