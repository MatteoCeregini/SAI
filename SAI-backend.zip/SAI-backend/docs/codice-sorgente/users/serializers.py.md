# serializers.py

### class UserSerializer(serializers.ModelSerializer)

Rappresenta un [serializer](https://www.django-rest-framework.org/api-guide/serializers/#modelserializer) usato per creare un utente.
